# genshin-chrome-themes
A collection of chrome themes based around characters from the game Genshin impact
